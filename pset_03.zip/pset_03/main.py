from luigi import build
from pset.tasks.embeddings.load_embeding import EmbedStudentData
from pset.tasks.embeddings.load_rank import NearestStudents

if __name__ == '__main__':
    #build([EmbedStudentData(path='/Users/adcxdpf/ms/pset/tasks/data')], local_scheduler=False)
    build([NearestStudents()], local_scheduler=False)
