=====
Usage
=====

To use Jinja Luigi Workflow in a project::

    import luigi_workflow
