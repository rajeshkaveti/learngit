export PYTHONPATH=.

echo "Generating python file based on jinja template....."
python main.py demo workflow_def.json

ls -lrt luigi_workflow/workflow/demo.py


cd luigi_workflow/workflow/

echo "Submitting generated luigi workflow to Spark....."
export PYTHONPATH=.:$PYTHONPATH:/Users/madhup/luigi_workflow

python demo.py ~/luigi_workflow 100
