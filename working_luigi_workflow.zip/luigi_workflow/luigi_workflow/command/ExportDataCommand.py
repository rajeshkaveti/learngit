import os
import time

class ExportDataCommand():

    @staticmethod
    def createfolder(folderPath):
        if not os.path.exists(folderPath):
            os.makedirs(folderPath)

    @staticmethod
    def saveDataFrame(df, outFile):
        ExportDataCommand.createfolder(outFile[0:outFile.rindex('/')])
        df.write.format("csv").option("header","true").mode('overwrite').save(outFile, index=False, index_label=False)

    @staticmethod
    def execute(df, fileFormat, outFile):
        ExportDataCommand.createfolder(outFile[0:outFile.rindex('/')])
        outFile = outFile + str(time.time())

        if (fileFormat == 'csv'):
            ExportDataCommand.__exportCSV(df, outFile)

        return outFile


    @staticmethod
    def __exportCSV(df, outFile):
        df.coalesce(1).write.option("header", "true").csv(outFile)
