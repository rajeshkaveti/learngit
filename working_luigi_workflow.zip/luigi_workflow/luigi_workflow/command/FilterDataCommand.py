
class FilterDataCommand():

    @staticmethod
    def execute(spark, df, condition_exp):
        df.createTempView("df")

        sql_exp = "select * from df where " + condition_exp

        print("filter sql : ", sql_exp)

        df = spark.sql(sql_exp)

        print("filter df : ", df.show())

        return df
