import luigi
import sys
import os
sys.path.insert(1, os.path.join(sys.path[0],'../command'))

from luigi_workflow.command.LoadDataCommand import LoadDataCommand
from luigi_workflow.command.ExportDataCommand import ExportDataCommand
from luigi_workflow.command.FilterDataCommand import FilterDataCommand
from luigi_workflow.command.JoinDataCommand import JoinDataCommand
from luigi_workflow.command.SelectDataColumnsCommand import SelectDataColumnsCommand

from luigi.contrib.spark import PySparkTask
from luigi.local_target import LocalTarget

from pyspark.sql import SparkSession

class ParameterCollector(object):
	
	 sourcePath = luigi.Parameter()
	
	 outputPath = luigi.Parameter()
	
	 run_id = luigi.Parameter()
	

	 def collect_params(self):
	    return {
			     
				  'sourcePath' : self.sourcePath,
			     
				  'outputPath' : self.outputPath,
			     
				  'run_id' : self.run_id,
			     
			   }


class Source_Load_countrycode_DataTask(ParameterCollector, luigi.ExternalTask):

    def requires(self):
        pass

    def output(self):
        return LocalTarget(self.sourcePath + "/" + "country_code.csv")

class Load_countrycode_DataTask(ParameterCollector, PySparkTask):
    def requires(self):
        return Source_Load_countrycode_DataTask(**self.collect_params())

    def output(self):
        return LocalTarget(self.outputPath + "/" + "ETL_Workflow" + "/" + self.run_id + "/" + "load_country_code" + ".csv")

    def main(self, sc, *args):
        spark = SparkSession(sc)
        df = LoadDataCommand.execute(spark, "csv", self.input().path)
        ExportDataCommand.saveDataFrame(df, self.output().path)

class Source_Load_billdtls_DataTask(ParameterCollector, luigi.ExternalTask):

    def requires(self):
        pass

    def output(self):
        return LocalTarget(self.sourcePath + "/" + "bill_details.csv")

class Load_billdtls_DataTask(ParameterCollector, PySparkTask):
    def requires(self):
        return Source_Load_billdtls_DataTask(**self.collect_params())

    def output(self):
        return LocalTarget(self.outputPath + "/" + "ETL_Workflow" + "/" + self.run_id + "/" + "load_bill_details" + ".csv")

    def main(self, sc, *args):
        spark = SparkSession(sc)
        df = LoadDataCommand.execute(spark, "csv", self.input().path)
        ExportDataCommand.saveDataFrame(df, self.output().path)

class Select_billdtls_DataTask(ParameterCollector, PySparkTask):

    def requires(self):
        return { "df" : Load_billdtls_DataTask(**self.collect_params()) }

    def output(self):
        return LocalTarget(self.outputPath + "/" + "ETL_Workflow" + "/" + self.run_id + "/" + "select_billdtls" + ".csv")

    def main(self, sc, *args):
        spark = SparkSession(sc)
        df_input = spark.read.format("csv").option("header", "true").load(self.input()["df"].path)
        df = SelectDataColumnsCommand.execute(df_input, ['bill_date', 'invoice_number', 'name', 'country_code', 'bill_amount'])
        ExportDataCommand.saveDataFrame(df, self.output().path)

class Select_countrycode_DataTask(ParameterCollector, PySparkTask):

    def requires(self):
        return { "df" : Load_countrycode_DataTask(**self.collect_params()) }

    def output(self):
        return LocalTarget(self.outputPath + "/" + "ETL_Workflow" + "/" + self.run_id + "/" + "select_countrycode" + ".csv")

    def main(self, sc, *args):
        spark = SparkSession(sc)
        df_input = spark.read.format("csv").option("header", "true").load(self.input()["df"].path)
        df = SelectDataColumnsCommand.execute(df_input, ['ctry_code', 'country_name'])
        ExportDataCommand.saveDataFrame(df, self.output().path)

class Filter_countrycode_DataTask(ParameterCollector, PySparkTask):
    def requires(self):
        return { "df" : Select_countrycode_DataTask(**self.collect_params()) }

    def output(self):
        return LocalTarget(self.outputPath + "/" + "ETL_Workflow" + "/" + self.run_id + "/" + "filter_countrycode" + ".csv")

    def main(self, sc, *args):
        spark = SparkSession(sc)
        df = spark.read.csv(self.input()["df"].path, header=True)
        conditionStr= "(df.ctry_code == 'US')"
        filteredDf = FilterDataCommand.execute(spark, df, conditionStr)
        ExportDataCommand.saveDataFrame(filteredDf, self.output().path)

class Filter_billdtls_DataTask(ParameterCollector, PySparkTask):
    def requires(self):
        return { "df" : Select_billdtls_DataTask(**self.collect_params()) }

    def output(self):
        return LocalTarget(self.outputPath + "/" + "ETL_Workflow" + "/" + self.run_id + "/" + "filter_billdtls" + ".csv")

    def main(self, sc, *args):
        spark = SparkSession(sc)
        df = spark.read.csv(self.input()["df"].path, header=True)
        conditionStr= "(df.invoice_number == 'TM10298')"
        filteredDf = FilterDataCommand.execute(spark, df, conditionStr)
        ExportDataCommand.saveDataFrame(filteredDf, self.output().path)

class Join_invoice_DataTask(ParameterCollector, PySparkTask):

    def requires(self):
        return {	"dfLeft" : Filter_billdtls_DataTask(**self.collect_params()),
                    "dfRight" : Filter_countrycode_DataTask(**self.collect_params())
                }

    def output(self):
        return LocalTarget(self.outputPath + "/" + "ETL_Workflow" + "/" + self.run_id + "/" + "join_country_billdtls" + ".csv")

    def main(self, sc, *args):
        spark = SparkSession(sc)
        dfLeft = spark.read.csv(self.input()["dfLeft"].path, header=True)
        dfRight = spark.read.csv(self.input()["dfRight"].path, header=True)
        joinCond=(dfLeft['country_code'] == dfRight['ctry_code'])
        joinType="inner"
        dfJoin = JoinDataCommand.execute(dfLeft, dfRight, joinCond, joinType)
        ExportDataCommand.saveDataFrame(dfJoin, self.output().path)

class File_delivery_DataTask(ParameterCollector, PySparkTask):

    def requires(self):
        return {"df" : Join_invoice_DataTask(**self.collect_params())}

    def output(self):
        return LocalTarget(self.outputPath + "/" + "ETL_Workflow" + "/" + self.run_id + "/" + "invoice_summary")

    def main(self, sc, *args):
        spark = SparkSession(sc)
        df = spark.read.csv(self.input()["df"].path, header=True)
        ExportDataCommand.saveDataFrame(df, self.output().path)

if __name__ == '__main__':
	if (len(sys.argv) != 3):
		raise Exception('Pass project home path and run id value....')

	root_path = sys.argv[1]
	run_id = sys.argv[2]

	luigiTask = []

	passingParams = {
		
		  "sourcePath":root_path + "/data/source",
		
		  "outputPath":root_path + "/data/output",
		
		  "run_id":root_path + "None",
		
	}

	passingParams["run_id"] = run_id
	
	luigiTask.append(File_delivery_DataTask(**passingParams))
	

	luigi.build(luigiTask, local_scheduler=True)

