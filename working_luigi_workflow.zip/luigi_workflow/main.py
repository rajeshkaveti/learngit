import json
import sys
import os
import luigi

from jinja2 import Environment, FileSystemLoader

scriptDirectory = os.path.dirname(os.path.realpath(__file__))

_template_locator = scriptDirectory + '/luigi_workflow/template'
_model_locator = scriptDirectory + '/data/model/'

__templateMap = {
    "LoadDataTask": 'LoadTemplate.txt',
    "SelectDataColumnsTask": 'SelectTemplate.txt',
    "JoinDataTask": 'JoinTemplate.txt',
    "FilterDataTask": 'FilterTemplate.txt',
    "FileDeliveryTask": 'FileDeliveryTemplate.txt',
    "LuigiBuild": 'luigiBuildTemplate.txt',
    "Parameters": 'ParameterTemplate.txt',
}

file_loader = FileSystemLoader(_template_locator)
env = Environment(loader=file_loader)
generated_workflow_source = None


def get_workflow_dict(filename):
    try:
        workflow_model = _model_locator + filename
        with open(workflow_model, 'r') as f:
            wk_dict = json.load(f)

        return wk_dict
    except Exception as err:
        print(err)


def get_workflow_elements(wk_dict):
    element_list = []
    for elem in resp_dict:
        element_list.append(elem)
    return element_list


def get_appName(wk_def_dict):
    return wk_def_dict['params']['appName']


def get_tasks(wk_def_dict):
    return wk_def_dict['tasks']


def get_dependencyGraph(wk_def_dict):
    return wk_def_dict['dependencyGraph']


def get_AppParams(wk_def_dict):
    return wk_def_dict['params']


def get_task(tasks):
    print("Under function : ", tasks)
    for taskId in tasks:
        yield tasks[taskId]


def get_taskParams(taskDef):
    return taskDef['params']


def __fillTemplate(taskType, args):
    return env.get_template(__templateMap[taskType]).render(args)


def __populateTaskParams(commonParams, taskParams, taskId, requiredDep):
    args = commonParams.copy()
    args.update(taskParams)
    args['taskId'] = taskId
    args['requiredTaskIds'] = requiredDep
    return args


def _generateWorkflow(source_code):
    generated_workflow_source.write(source_code)
    generated_workflow_source.write("\n\n")
    generated_workflow_source.flush()


def __getRootTask(depGraph):
    rootTasks = depGraph.copy()
    for key in depGraph:
        deps = depGraph[key]
        for dep in deps:
            try:
                del rootTasks[dep]
            except KeyError:
                print("Key 'testing' not found")
    return rootTasks.keys()


if __name__ == '__main__':
    if (len(sys.argv) != 3):
        raise Exception('Pass 2 arguments: appname and workflow definition file....')
    appName = sys.argv[1]
    workFlowJson = sys.argv[2]

    fileName = scriptDirectory + '/luigi_workflow/workflow/' + appName + '.py'
    print(fileName)
    generated_workflow_source = open(fileName, 'w')

    try:
        resp_dict = get_workflow_dict(workFlowJson)
        #print("Workflow definition dictionary : ", resp_dict)

        element_list = get_workflow_elements(resp_dict)
        #print("Elements in workflow definition file : ", element_list)

        wk_tasks = get_tasks(resp_dict)

        dependencyGraph = get_dependencyGraph(resp_dict)
        #print("Dependency Graph : ", dependencyGraph)

        commonParams = get_AppParams(resp_dict)
        #print("commonParams : ", commonParams)

        passingArgs = {
            "params": {"sourcePath": "/data/source",
                       "outputPath": "/data/output",
                       "run_id": None
                       }
        }

        _generateWorkflow(__fillTemplate("Parameters", passingArgs))

        wk_task = get_task(wk_tasks)

        for task in wk_task:
            print("***", task)
            taskParams = get_taskParams(task)
            taskId = taskParams['stepName']
            params = __populateTaskParams(commonParams, taskParams, taskId, dependencyGraph[taskId])
            _generateWorkflow(__fillTemplate(task['taskType'], params))

        rootTasks = __getRootTask(dependencyGraph)
        passingArgs['rootTasks'] = rootTasks
        passingArgs['appName'] = appName

        _generateWorkflow(__fillTemplate("LuigiBuild", passingArgs))

    except Exception as err:
        print(err)
