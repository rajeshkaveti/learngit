from luigi import build
from pset.tasks.embeddings import EmbedStudentData

if __name__ == '__main__':
    build([EmbedStudentData()], local_scheduler=True)
