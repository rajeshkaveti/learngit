from luigi import ExternalTask
from luigi import Task
import luigi
import os
from pset.tasks.data.w_embedding import WordEmbedding
import pandas as pd

class HashedStudentData(ExternalTask):
    path = luigi.Parameter()
    
    def output(self):
        print("************Inside HashedStudentData**********")

        return luigi.LocalTarget(os.path.join(self.path, 'hashed.xlsx'))
        
        
class Words(ExternalTask):
    path = luigi.Parameter()
            
    def output(self):
        print("************Inside Words**********")
        return luigi.LocalTarget(os.path.join(self.path, 'words.txt'))


class WordVectors(ExternalTask):
    path = luigi.Parameter()
    
    def requires(self):
        # Note the clone method - avoid creating task instances directly
        print("************Inside WordVectors**********")
        return self.clone(Words)
        
    def output(self):
        return luigi.LocalTarget(os.path.join(self.path, 'vectors.npy.gz') , format=luigi.format.Nop)
        
        
    def load_embedding(self):
        """Convenience method to load a :class:`.WordEmbedding`"""

        word_target = self.input()
        vec_target = self.output()
        
        print("************Inside load_embedding**********")
        
        return WordEmbedding(word_target,vec_target)

        # Use these targets to return a WordEmbedding instance
        
        
