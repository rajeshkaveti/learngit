from ..data.load_dataset import *
import luigi
import xlrd
import pandas as pd

class EmbedStudentData(luigi.Task):
    """Describe each Task"""
    path = luigi.Parameter()

    def requires(self):
        # You can return more than one req, using a dict or list
        return {
            'data': HashedStudentData(self.path),
            'embedding': WordVectors(self.path)
        }

    def run(self):
        reqs = self.requires()
        
        xls_data = (self.input()['data'].open('r'))
        embedding = (self.input()['embedding'].open('r'))
        
        print("***************:::::" , xls_data)
        print("***************:::::" , embedding)
        
