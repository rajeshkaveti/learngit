====================
Jinja Luigi Workflow
====================


.. image:: https://img.shields.io/pypi/v/luigi_workflow.svg
        :target: https://pypi.python.org/pypi/luigi_workflow

.. image:: https://img.shields.io/travis/rkaveti/luigi_workflow.svg
        :target: https://travis-ci.org/rkaveti/luigi_workflow

.. image:: https://readthedocs.org/projects/luigi-workflow/badge/?version=latest
        :target: https://luigi-workflow.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status




Luigi based workflow using Jinja template generated from JSON configuration file. Uses spark for task execution.


* Free software: GNU General Public License v3
* Documentation: https://luigi-workflow.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
