# -*- coding: utf-8 -*-

"""Top-level package for Jinja Luigi Workflow."""

__author__ = """Rajesh Kaveti"""
__email__ = 'kaveti.rajesh@gmail.com'
__version__ = '0.1.0'
