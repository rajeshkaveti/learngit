
class FilterDataCommand():

    @staticmethod
    def execute(spark, df, condition_exp):
        df.createTempView("df")

        sql_exp = "select * from df where " + condition_exp

        df = spark.sql(sql_exp)
        return df
