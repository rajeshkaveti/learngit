import os
import time

class ExportDataCommand():

    @staticmethod
    def createfolder(folderPath):
        if not os.path.exists(folderPath):
            os.makedirs(folderPath)

    @staticmethod
    def execute(df, fileFormat, outFile):
        ExportDataCommand.createfolder(outFile[0:outFile.rindex('/')])
        outFile = outFile + str(time.time())

        if (fileFormat == 'csv'):
            ExportDataCommand.__exportCSV(df, outFile)

        return outFile


    @staticmethod
    def __exportCSV(df, outFile):
        df.coalesce(1).write.option("header", "true").csv(outFile)
