import os

class LoadDataCommand():

    @staticmethod
    def execute(spark, fileFormat, filePath):

        fileName = filePath[filePath.rindex('/') + 1:]
        print(fileName)

        if (fileFormat == 'csv'):
            df = LoadDataCommand.__loadCSV(spark, filePath)

        elif (fileFormat == 'json'):
            df = LoadDataCommand.__loadJSON(spark, filePath)

        return df


    @staticmethod
    def __loadCSV(spark, filename):
        return spark.read.csv(filename, header=True, sep=",")

    @staticmethod
    def __loadJSON(spark, filename):
        return spark.read.json(filename)
