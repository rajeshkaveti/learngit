
class SelectDataColumnsCommand():

    @staticmethod
    def execute(df, colNames):

        if not colNames or colNames[0] == 'ALL':
            ndf = df
        else:
            ndf = df.select(colNames)

        return ndf
