
class JoinDataCommand():

    @staticmethod
    def execute(ds1, ds2, join_exp, join_type):

        df = ds1.join(ds2, join_exp, how=join_type)
        return df
