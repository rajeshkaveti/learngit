from luigi import build
from pset.tasks.embeddings.load_embeding import EmbedStudentData

if __name__ == '__main__':
    build([EmbedStudentData(path='/Users/adcxdpf/ms/pset/tasks/data')], local_scheduler=False)
