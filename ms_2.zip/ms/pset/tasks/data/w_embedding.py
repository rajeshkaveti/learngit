import pandas as pd
import numpy as npy
import xlrd
import re
import hashlib
import sys

base_dir = '/app/pset/tasks/data/'


class WordEmbedding(object):
    
    def __init__(self, words, vector):
       self.words=words
       self.vector=vector
       

    def __call__(self, word):
        """Embed a word

        :returns: vector, or None if the word is outside of the vocabulary
        :rtype: ndarray
        """
        try:
            #print("Inside call function ***" , word)
            wordIndex=self.words.index(word.lower())
            #print(wordIndex)
            #print(self.vector[wordIndex])
            return self.vector[wordIndex]
        except ValueError:
            return None
        
    
        # Consider how you implement the vocab lookup.  It should be O(1).
        
    def load_words(filename):
        with open(filename, "r") as fd:
            lines = fd.read().splitlines()
        return lines
    
    def load_data(filename):
        data = pd.read_excel(filename,0)
        return data
    
    
    def load_vectors(filename):
        vector = npy.load(filename)
        return vector    
    

    def tokenize(self,text):
        # Get all "words", including contractions
        # eg tokenize("Hello, I'm Scott") --> ['Hello', "I'm", "Scott"]
        return re.findall("\w[\w']+", text)
    
    def cosine_similarity(a, b):
    #     """Takes 2 vectors a, b and returns the cosine similarity according 
    #     to the definition of the dot product
    #     """
    #     dot_product = npy.dot(a, b)
    #     norm_a = npy.linalg.norm(a)
    #     norm_b = npy.linalg.norm(b)
    #     return dot_product / (norm_a * norm_b)
    
    
        dot_product = npy.dot(a[0], b.T)
        print(dot_product)
        norm_a = npy.linalg.norm(a)
        norm_b = npy.linalg.norm(b)
        print(norm_a)
        print(norm_b)
        print((norm_a * norm_b))
        return dot_product / (norm_a * norm_b)
        

    def my_distance(vec):
        return 1 - cosine_similarity(vec, my_vec.values[0][0])        
    
         
    def embed_document(self, text):
        
        words = self.tokenize(text)
        #print("words ::" , words)
        sent_vec = npy.zeros((1 , 300))
        for w in words:

            try:
                vc = self(w)
                #print("********vc[0] ::: " , vc[0])
                sent_vec = npy.add(sent_vec, vc) 
    #                 print(sent_vec[0][0])
            except:
                pass
        #print(sent_vec)
        return sent_vec

    def test_function(self):
        print('$$$$$$$$$$ hello world; during deserialization self.words is --> !', self.words)
        print('$$$$$$$$$$ hello world; during deserialization self.vector is --> !', self.vector)

    @classmethod
    def from_files(cls, word_file, vec_file):
        """Instanciate an embedding from files

        Example::

            embedding = WordEmbedding.from_files('words.txt', 'vecs.npy.gz')

        :rtype: cls
        """
        with open(word_file, "r") as fd:
            lines = fd.read().splitlines()

        vector = npy.load(vec_file)

        return cls(lines, vector)

