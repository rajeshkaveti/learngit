from luigi import ExternalTask
from luigi import Task
import luigi
import os
from pset.tasks.data.w_embedding import WordEmbedding
import pandas as pd
import pickle

class HashedStudentData(ExternalTask):
    path = luigi.Parameter()
    
    def output(self):
        print("************Inside HashedStudentData**********")

        return luigi.LocalTarget(os.path.join(self.path, 'hashed.xlsx'))
        
        
class Words(ExternalTask):
    path = luigi.Parameter()
            
    def output(self):
        print("************Inside Words**********")
        return luigi.LocalTarget(os.path.join(self.path, 'words.txt'))


class WordVectors(Task):
    path = luigi.Parameter()
    
    def requires(self):
        # Note the clone method - avoid creating task instances directly
        print("************Inside WordVectors**********")
        return self.clone(Words)
        
    def output(self):
        
        return { 'out1' : luigi.LocalTarget(os.path.join(self.path, 'vectors.npy.gz') , format=luigi.format.Nop),
                 'out2' : luigi.LocalTarget('/Users/adcxdpf/ms/pset/out2.txt', format=luigi.format.Nop) }
        #return luigi.LocalTarget(os.path.join(self.path, 'vectors.npy.gz') , format=luigi.format.Nop)
        
    def run(self):
        weInstance = self.load_embedding()
        with self.output()['out2'].open(mode='wb') as f:
            pickle.dump(weInstance, f, protocol=pickle.HIGHEST_PROTOCOL)
        
        #print("***************:::::" , xls_data)
        #print("***************:::::" , embedding)
        
    def load_embedding(self):
        """Convenience method to load a :class:`.WordEmbedding`"""

        word_target = self.input()
        word_target_path = self.input().path
        #print('####### during creation word_target ######', word_target)
        vec_target = self.output()['out1']
        #print('####### during creation vec_target ######', vec_target)
        vec_target_path = self.output()['out1'].path

        print('####### word_target_path ######', word_target_path)
        print('####### vec_target_path ######', vec_target_path)
        
        print("************Inside load_embedding**********")

        wordEmbedding = WordEmbedding.from_files(word_target_path,vec_target_path)
        
        return wordEmbedding

        # Use these targets to return a WordEmbedding instance
        
        
