from ..data.load_dataset import *
import luigi
import xlrd
import pandas as pd
import pickle

class EmbedStudentData(luigi.Task):
    """Describe each Task"""
    path = luigi.Parameter()

    def requires(self):
        # You can return more than one req, using a dict or list
        return {
            'data': HashedStudentData(self.path),
            'embedding': WordVectors(self.path)
         }
         
    def output(self):
        return luigi.LocalTarget(os.path.join(self.path, 'df.csv'))


    def run(self):
        #reqs = self.requires()
        print('hello EmbedStudentData')
        
        xls_data = (self.input()['data'].open(mode='r'))
        embedding = (self.input()['embedding']['out2'].open(mode='rb'))

        x = pickle.load(embedding)
        #x.test_function()
        print('*************** type of x ', type(x))
        print('*************** type of xls_data ', type(xls_data))
        
        xls_target_path = self.input()['data'].path
        print('*************** xls_target_path ', xls_target_path)
        
        ret_vect = x.embed_document('Get fluent with')
        print('######## ret_vect : ', ret_vect)
        
        
        pd_xls_data = pd.read_excel(xls_target_path,0)
        
        #print(pd_xls_data)
        pd_xls_data.set_index('hashed_id')
        
        pd_xls_data['learn'] = pd_xls_data['learn'].fillna(value='ZERO')
        pd_xls_data['project'] = pd_xls_data['project'].fillna(value='ZERO')
        
        learnvecs = pd_xls_data['learn'].apply(x.embed_document) 
        projvecs = pd_xls_data['project'].apply(x.embed_document)
        
        print (learnvecs.shape)
        print (projvecs.shape)
        
        vecs = learnvecs + projvecs
        
        print(vecs.shape)
        
        vecs_list = pd.Series(vecs)
        
        df = pd.DataFrame(vecs, index=vecs_list.index)
        df.columns = ['vectors']
        type(df['vectors'])

        print(df)
        
        # output data
        f = self.output().open('w')
        df.to_csv(f, sep='\t', encoding='utf-8', index=None)
        f.close()
        
        
        
        
        

        
        
        