# -*- coding: utf-8 -*-

import luigi
import pandas as pd

class NearestStudents(Task):

    github_id = Parameter(default='b280302a', description='Github id to search nearby (not hashed)')
    n = IntParameter(default=5, description='Output top N')
    farthest = BoolParameter(default=False, description='Find farthest instead')

    def output(self):
        ### Ensure the parameters are reflected in the filename!
        pass

    def requires(self):
        return self.clone(EmbedStudentData)