from luigi import ExternalTask
from luigi import Task
import luigi
import os

class TestTask(Task):
    path = luigi.Parameter()
    
    def requires(self):
        print("*********path from command line ********: " , self.path)  
        return self.clone(HashedStudentData)
    
    def run(self):
        # Placeholder
        pass
