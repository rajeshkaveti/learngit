
import numpy as np
import pandas as pd


def load_words(filename):
    with open(filename, "r") as fd:
        lines = fd.read().splitlines()
    return lines

def load_data(filename):
    data = pd.read_excel(filename,0)
    return data

def load_vectors(filename):
    vector = np.load(filename)
    return vector

def tokenize(text):
    # Get all "words", including contractions
    # eg tokenize("Hello, I'm Scott") --> ['Hello', "I'm", "Scott"]
    return re.findall("\w[\w']+", text)
