import sys
import hashlib

def hash_str(some_val, salt):
    m = hashlib.sha256()
    m.update(salt)
    m.update(some_val.encode())
    return m.digest().hex()


SALT =  sys.argv[1]
CSCI_SALT = bytes.fromhex(SALT)
hash_id = hash_str('rajeshkaveti',CSCI_SALT)
