=======
History
=======

0.1.0 (2018-09-28)
------------------

* First release on PyPI.
